"""Unit tests for the risk management engine."""

import unittest
import sys
from pathlib import Path

# Add project root to sys.path for trading package imports
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from types import SimpleNamespace

from trading.risk import RiskManager


class TestRiskManager(unittest.TestCase):
    def setUp(self) -> None:
        # Default risk manager with low thresholds for testing
        self.risk = RiskManager(max_open_positions=2, max_risk_per_trade=50.0, max_total_risk=80.0, contract_multiplier=100)
        # Simple signal stub with required attributes
        self.Signal = lambda entry, stop: SimpleNamespace(symbol="TEST", entry_price=entry, stop_price=stop)

    def test_accepts_when_within_limits(self):
        sig = self.Signal(1.50, 1.00)
        accepted, reason = self.risk.should_accept(sig, quantity=1)
        self.assertTrue(accepted)

    def test_rejects_when_trade_risk_too_high(self):
        # Risk per contract = (2.00 - 1.00)*100 = 100 which exceeds max_risk_per_trade=50
        sig = self.Signal(2.00, 1.00)
        accepted, reason = self.risk.should_accept(sig, quantity=1)
        self.assertFalse(accepted)

    def test_rejects_when_total_risk_exceeded(self):
        # First trade uses 40 risk, second would push total over 80
        sig1 = self.Signal(1.40, 1.00)  # risk 40
        self.assertTrue(self.risk.should_accept(sig1, 1)[0])
        self.risk.register_trade(sig1, 1)
        sig2 = self.Signal(1.40, 1.00)  # another 40 risk
        accepted, reason = self.risk.should_accept(sig2, 1)
        self.assertFalse(accepted)

    def test_rejects_when_max_positions_reached(self):
        sig = self.Signal(1.50, 1.00)
        # Fill two positions
        for _ in range(2):
            self.assertTrue(self.risk.should_accept(sig, 1)[0])
            self.risk.register_trade(sig, 1)
        # Third trade should be rejected
        accepted, reason = self.risk.should_accept(sig, 1)
        self.assertFalse(accepted)


if __name__ == "__main__":
    unittest.main()
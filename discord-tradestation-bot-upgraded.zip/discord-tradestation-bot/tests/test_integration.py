"""Integration test skeleton for the trading system.

This test demonstrates how components can be wired together and how
events propagate through the system.  It uses dummy implementations of
TradeStationClient to avoid network requests.  In a real test suite you
would mock network calls and simulate Discord messages.
"""

import asyncio
import unittest
from types import SimpleNamespace
from datetime import datetime
from typing import Any
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from trading.events import EventBus, AlertEvent, OrderEvent, RiskEvent  # type: ignore
from trading.execution import ExecutionManager
from trading.risk import RiskManager
from trading.tradestation_client import TradeStationClient


class DummyClient(TradeStationClient):
    def __init__(self) -> None:
        # Do not call super().__init__; avoid environment variables
        pass

    def submit_bracket_order(self, signal: Any, quantity: int = 1) -> dict:
        # Simulate a successful order submission
        return {"orderId": "dummy", "status": "ok"}


class TestIntegration(unittest.IsolatedAsyncioTestCase):
    async def test_end_to_end(self):
        bus = EventBus()
        client = DummyClient()
        risk = RiskManager(max_open_positions=1, max_risk_per_trade=100.0, max_total_risk=100.0, contract_multiplier=100)
        exec_manager = ExecutionManager(bus, client, risk, quantity=1)
        events = []

        async def record_order(event: OrderEvent):
            events.append(event)

        bus.subscribe(OrderEvent, record_order)
        # Create a simple signal
        signal = SimpleNamespace(symbol="TEST", strike=50.0, option_type="Call", expiration_date="2099-12-31", entry_price=2.00, stop_price=1.50)
        await bus.publish(AlertEvent(timestamp=datetime.utcnow(), signal=signal, raw_message=""))
        # Wait a moment for tasks to run
        await asyncio.sleep(0.1)
        self.assertEqual(len(events), 1)
        self.assertIn("orderId", events[0].response)


if __name__ == "__main__":
    unittest.main()